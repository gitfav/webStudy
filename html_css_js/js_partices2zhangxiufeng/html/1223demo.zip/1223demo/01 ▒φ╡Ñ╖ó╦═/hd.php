<?php
header('Content-Type: text/html; charset=utf-8'); 
echo '<pre>';
print_r($_POST);
echo '</pre>';